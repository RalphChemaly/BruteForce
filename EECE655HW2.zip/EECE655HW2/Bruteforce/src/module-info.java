module Bruteforce {
	requires java.sql;
}